import * as React from "react";

/**
 * Minimal Slider implementing the Radix-style API the game uses:
 * `value={[n]}`, `onValueChange([n])`, `min`, `max`, `step`,
 * `className`. Built on a native range input so the project runs
 * with zero extra dependencies beyond recharts.
 */
export interface SliderProps {
  value?: number[];
  onValueChange?: (v: number[]) => void;
  min?: number;
  max?: number;
  step?: number;
  className?: string;
  disabled?: boolean;
}

const Slider = React.forwardRef<HTMLInputElement, SliderProps>(
  (
    { value, onValueChange, min = 0, max = 100, step = 1, className = "", disabled },
    ref
  ) => (
    <input
      ref={ref}
      type="range"
      disabled={disabled}
      className={`h-1.5 w-full cursor-pointer appearance-none rounded-full bg-slate-700 accent-amber-400 ${className}`}
      style={{ accentColor: "#fbbf24" }}
      min={min}
      max={max}
      step={step}
      value={value?.[0] ?? min}
      onChange={(e) => onValueChange?.([Number(e.target.value)])}
    />
  )
);
Slider.displayName = "Slider";

export { Slider };
