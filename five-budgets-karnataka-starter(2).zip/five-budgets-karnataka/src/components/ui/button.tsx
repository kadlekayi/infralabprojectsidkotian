import * as React from "react";

/**
 * Minimal Button matching the shadcn/ui API surface the game uses
 * (`variant`, `size`, `className`). Variant colors are left off the
 * "default" variant because the game always supplies its own
 * background/text classes (e.g. bg-amber-500) — this way custom
 * classes always win.
 */
type Variant = "default" | "outline" | "secondary" | "ghost" | "destructive";
type Size = "default" | "sm" | "lg" | "icon";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const variantClasses: Record<Variant, string> = {
  default: "",
  outline: "border border-white/20 bg-transparent text-slate-200 hover:bg-white/10",
  secondary: "bg-slate-700/70 text-slate-100 hover:bg-slate-600/70",
  ghost: "text-slate-200 hover:bg-white/10",
  destructive: "bg-rose-600 text-white hover:bg-rose-500",
};

const sizeClasses: Record<Size, string> = {
  default: "h-9 px-4 text-sm",
  sm: "h-8 px-3 text-xs",
  lg: "h-11 px-6 text-base",
  icon: "h-9 w-9",
};

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className = "", variant = "default", size = "default", type, ...props }, ref) => (
    <button
      ref={ref}
      type={type ?? "button"}
      className={`inline-flex select-none items-center justify-center gap-1 rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/50 disabled:pointer-events-none disabled:opacity-50 ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      {...props}
    />
  )
);
Button.displayName = "Button";

export { Button };
